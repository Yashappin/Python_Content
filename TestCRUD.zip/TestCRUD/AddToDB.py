#!C:\Program Files\Python37\Python.exe
print("Content-type:text/html \n")

import cgi
import mysql.connector
myDB = mysql.connector.connect(host="localhost", user="root", passwd="", database = "db1")
myCursor = myDB.cursor()

form = cgi.FieldStorage()

name = form.getvalue("nm")
salary = form.getvalue("sal")

myCursor.execute("insert into emp(name, salary) values ('{}', {})".format(name, float(salary)))
myDB.commit()


redirectURL = "http://localhost/first.html"
print('<html>')
print('  <head>')
print('    <meta http-equiv="refresh" content="0;url='+str(redirectURL)+'" />') 
print('  </head>')
print('</html>')



