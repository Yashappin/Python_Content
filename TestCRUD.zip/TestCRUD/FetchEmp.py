#!C:\Program Files\Python37\Python.exe
print("Content-type:text/html \n")

import cgi
import mysql.connector
myDB = mysql.connector.connect(host="localhost", user="root", passwd="", database = "db1")
myCursor = myDB.cursor()


myCursor.execute("select * from emp")
res = myCursor.fetchall()

print("""
<html><head><title>All Employee</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
</head><body>
<table class="table">
<tr>
<th>ID</th>
<th>Name</th>
<th>Salary</th>
<th>Delete</th>
<th>Update</th>
</tr>
""")

for i in res:
    print("<tr>")
    for j in i:
        print("<td>",j,"</td>")
    print("<td><a href="'{}'"><button>Delete</button></a></td>".format("deleteemp.py?eid="+str(i[0])+""))
    print("<td><a href="'{}'"><button>Update</button></a></td>".format("UpdateEmp.py?eid="+str(i[0])+""))
    print("</tr>")


print("""
</table></body>
""")
