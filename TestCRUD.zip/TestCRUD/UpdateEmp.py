#!C:\Program Files\Python37\Python.exe
print("Content-type:text/html \n")

import cgi
import mysql.connector
myDB = mysql.connector.connect(host="localhost", user="root", passwd="", database = "db1")
myCursor = myDB.cursor()

form = cgi.FieldStorage()

empid = form.getvalue("eid")

myCursor.execute("select * from emp where id = {}".format(int(empid)))

res = myCursor.fetchone()

print('''
<form action="UpdateValues.py">
<input type="hidden" name="eid" value="{}"/>
<input type="text" name="updateNm" value="{}"/>
<input type="text" name="updateSal" value="{}"/>
<input type="submit" value="Update"/>
</form>

'''.format(res[0], res[1], res[2]))



