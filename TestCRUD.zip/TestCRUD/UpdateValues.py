#!C:\Program Files\Python37\Python.exe
print("Content-type:text/html \n")

import cgi
import mysql.connector
myDB = mysql.connector.connect(host="localhost", user="root", passwd="", database = "db1")
myCursor = myDB.cursor()

form = cgi.FieldStorage()

name = form.getvalue("updateNm")
salary = form.getvalue("updateSal")
empid = form.getvalue("eid")

myCursor.execute("update emp set name='{}', salary={} where id = {}".format(name, salary, empid))
myDB.commit()


redirectURL = "http://localhost/TestCRUD/FetchEmp.py"
print('<html>')
print('  <head>')
print('    <meta http-equiv="refresh" content="0;url='+str(redirectURL)+'" />') 
print('  </head>')
print('</html>')



