#!C:\Program Files\Python37\Python.exe
print("Content-type:text/html \n")

import cgi
import mysql.connector
myDB = mysql.connector.connect(host="localhost", user="root", passwd="", database = "db1")
myCursor = myDB.cursor()

form = cgi.FieldStorage()

empid = form.getvalue("eid")

myCursor.execute("delete from emp where id = {}".format(int(empid)))
myDB.commit()


redirectURL = "http://localhost/FetchEmp.py"
print('<html>')
print('  <head>')
print('    <meta http-equiv="refresh" content="0;url='+str(redirectURL)+'" />') 
print('  </head>')
print('</html>')



